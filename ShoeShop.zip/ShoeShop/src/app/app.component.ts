import { Component } from '@angular/core';
import { ITS_JUST_ANGULAR } from '@angular/core/src/r3_symbols';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  filterclicked =false;
  filterclickedMobile=false;
  title = 'neosoft';
  liked = true;
  priceFilter=["Rs. 1997 to Rs. 6172 ","Rs. 6172 to Rs. 10347","Rs. 10347 to Rs. 14522","Rs. 6172 to Rs. 10347","Rs. 14522 to Rs. 18697"
  ,"Rs. 10347 to Rs. 14522","Rs. 14522 to Rs. 18697"];
  CategoryFilter=["Tshirts","Track Pants","Sports Shoes","Tights","Casual Shoes","Shorts ","Tops","Sweatshirts"];
  mainCategory=["Men","Women","Boy","Girl"];
  colorFilter=["White","Blue","Black","Red"]
  filters= ['Size','color','Nike','casual','Footwear'];
  ItemsAvailable=[{
    itemName : "Bond Street By Red Tape Remixa Sneakers",
    itemCategory :"Men Crater Remixa Sneakers",
    rupees : 'Rs :564',
    img : "../assets/image 32.png",
    liked:true,
    over:false
  },

  {
    itemName : "Puma",
    itemCategory :"Men Crater Remixa Sneakers",
    rupees : 'Rs :564',
    img : "../assets/image 26.png",
    liked:true,
    over:false
  },
  {
    itemName : "Vero Moda",
    itemCategory :"Men Crater Remixa Sneakers",
    rupees : 'Rs :564',
    img : "../assets/image 35.png",
    liked:false,
    over:false
  },
  {
    itemName : "ADIDAS",
    itemCategory :"Men Crater Remixa Sneakers",
    rupees : 'Rs :564',
    img : "../assets/image 31.png",
    liked:false,
    over:false
  },
  {
    itemName : "Carnatia W Running Shoes For Women",
    itemCategory :"Men Crater Remixa Sneakers",
    rupees : 'Rs :2964',
    img : "../assets/image 29.png",
    liked:true,
    over:false
  }
]
  filterTabSelected='Gender';
likeClicked(itemSelected: string,liked: any){
  this.ItemsAvailable.forEach(element => {
    if(element.itemName == itemSelected){
      if(liked)
           element.liked= false;
           else
           element.liked =true;
    }

  });
  

}
filterTab(ids:any){
  this.filterTabSelected=ids;
}
FilterClose(){
  debugger;
  this.filterclicked = false;
  this.filterclickedMobile =false;
}
FilterShowMobile(){
  debugger;
  if(this.filterclickedMobile)
  this.filterclickedMobile = false;
  else
 this.filterclickedMobile=true;
}
FilterShow(){
  if(this.filterclicked)
  this.filterclicked = false;
  else
 this.filterclicked=true;
}
over(x:string,y:any){
  this.ItemsAvailable.forEach(element => {
    if(element.itemName == x){
      if(y)
           element.over= false;
           else
           element.over =true;
    }

  });

}



}
