var x=2;
function foo(){
  console.log(x);
}